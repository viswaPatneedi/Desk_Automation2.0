"""
Device Commands Configuration
"""

# Device control commands
device_status_command = "QueryPowerState\n"
reboot_command = "systemctl reboot\n"
deepsleep_command = "curl -s -X POST http://127.0.0.1:9001/as/test/preferences -d '{\"lowPowerTimerDuration\": \"20\"}'"
power_key_command = "keySimulator -ktvpower"
home_key_command = "keySimulator -khome"
enter_key_command = "keySimulator -kenter"
down_key_command = "keySimulator -kdown"
right_key_command = "keySimulator -kright"
left_key_command = "keySimulator -kleft"
up_key_command = "keySimulator -kup"
hard_power_off_command = "echo 1 > /proc/sys/kernel/sysrq; echo b > /proc/sysrq-trigger"