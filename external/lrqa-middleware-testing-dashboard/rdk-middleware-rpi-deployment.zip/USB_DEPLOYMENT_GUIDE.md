# RDK Middleware - Raspberry Pi Deployment Files

## Overview
This guide lists all files required to deploy the RDK Middleware Testing Dashboard on other Raspberry Pi devices.

**Total Size:** ~250MB (excluding large data directories)

---

## Directory Structure to Copy

```
deployment/
├── app.py                              # Main Flask application
├── requirements.txt                    # Python dependencies
├── Dockerfile.rpi                      # Docker image configuration
├── docker-compose.rpi.yml              # Docker compose deployment
├── docker-rpi-quickstart.sh            # Quick deployment script
├── .dockerignore                        # Docker build optimization
│
├── controllers/                         # Business logic
│   ├── __init__.py
│   ├── device_controller.py
│   ├── job_controller.py
│   ├── queue_controller.py
│   ├── results_controller.py
│   └── (all other controller files)
│
├── models/                              # Data models
│   ├── __init__.py
│   ├── device.py
│   ├── job.py
│   ├── user.py
│   ├── result.py
│   └── (all other model files)
│
├── services/                            # Background services
│   ├── __init__.py
│   ├── log_service.py
│   ├── queue_service.py
│   ├── recovery_service.py
│   ├── test_service.py
│   └── (all other service files)
│
├── utils/                               # Utility modules
│   ├── __init__.py
│   ├── device_lock_manager.py
│   ├── ssh_connectivity_test.py
│   ├── screenshot_utils.py
│   └── (all other utility files)
│
├── templates/                           # HTML templates
│   ├── index.html
│   ├── dashboard.html
│   ├── jobs.html
│   ├── job_details.html
│   ├── reboot_perf_results.html
│   └── (all other templates)
│
├── static/                              # Static assets
│   ├── css/
│   │   └── styles.css
│   ├── js/
│   │   ├── lock-status-monitor.js
│   │   └── (all other JS files)
│   └── images/
│
├── config_*.py                          # Configuration files
│   ├── config_commands.py
│   ├── config_timing.py
│   ├── config_ir_blaster.py
│   ├── config_screenshot.py
│   ├── config_log_patterns.py
│   ├── config_ssh_connection.py
│   ├── config_deployment.py
│   ├── config_email.py
│   ├── config_eta.py
│   ├── config_ai_vision.py
│   └── config_screen_validation.py
│
├── ssl/                                 # SSL certificates (if using HTTPS)
│   ├── cert.pem (optional)
│   └── key.pem (optional)
│
├── data/                                # Data files (created on first run)
│   ├── devices.json
│   ├── saved_sequences.json
│   ├── log_patterns.json
│   └── (other config JSON files)
│
└── docs/                                # Documentation
    ├── DOCKER_RPI_SETUP.md
    ├── DOCKER_RPI_QUICKSTART.md
    └── (deployment guides)
```

---

## Critical Files to Include

### MUST HAVE:
- ✅ `app.py` - Main application
- ✅ `requirements.txt` - Python dependencies
- ✅ `Dockerfile.rpi` - Container image
- ✅ `docker-compose.rpi.yml` - Deployment config
- ✅ `docker-rpi-quickstart.sh` - Setup script
- ✅ `controllers/` - All business logic
- ✅ `models/` - All data models
- ✅ `services/` - All services
- ✅ `templates/` - All HTML templates
- ✅ `static/` - CSS, JS, images
- ✅ `utils/` - Utility modules
- ✅ `config_*.py` - All config files

### SHOULD INCLUDE:
- ⚠️ `devices.json` - Device configuration
- ⚠️ `saved_sequences.json` - Test sequences
- ⚠️ `log_patterns.json` - Log patterns
- ⚠️ `config_log_patterns.py` - Log parsing
- ⚠️ `DOCKER_RPI_SETUP.md` - Setup guide

### DO NOT INCLUDE (too large):
- ❌ `venv/` - Will be rebuilt
- ❌ `logs/` - Runtime generated
- ❌ `screenshots/` - Runtime generated
- ❌ `iteration_logs/` - Runtime generated
- ❌ `device_logs/` - Runtime generated
- ❌ `SAM-CD-2GB/` - Reference only
- ❌ `updated_code/` - Backup only
- ❌ `backups/` - Old versions
- ❌ `.git/` - Git history
- ❌ `__pycache__/` - Python cache

---

## Files to Create Directories For (at runtime):

```bash
mkdir -p /app/logs
mkdir -p /app/iteration_logs
mkdir -p /app/screenshots
mkdir -p /app/captured_images
mkdir -p /app/device_logs
```

---

## USB Deployment Preparation

### 1. Create Directory Structure on USB:

```bash
# On a Linux/Mac machine with your development code
mkdir -p /mnt/usb/rdk-middleware-deployment

cd /home/lrqa/Desktop/viswa/Latest_Enhancement/Enhancement

# Copy all necessary directories and files
cp -r controllers /mnt/usb/rdk-middleware-deployment/
cp -r models /mnt/usb/rdk-middleware-deployment/
cp -r services /mnt/usb/rdk-middleware-deployment/
cp -r utils /mnt/usb/rdk-middleware-deployment/
cp -r templates /mnt/usb/rdk-middleware-deployment/
cp -r static /mnt/usb/rdk-middleware-deployment/
cp -r ssl /mnt/usb/rdk-middleware-deployment/ 2>/dev/null || true

# Copy all config files
cp config_*.py /mnt/usb/rdk-middleware-deployment/
cp app.py /mnt/usb/rdk-middleware-deployment/
cp requirements.txt /mnt/usb/rdk-middleware-deployment/

# Copy deployment scripts
cp Dockerfile.rpi /mnt/usb/rdk-middleware-deployment/
cp docker-compose.rpi.yml /mnt/usb/rdk-middleware-deployment/
cp docker-rpi-quickstart.sh /mnt/usb/rdk-middleware-deployment/
cp .dockerignore /mnt/usb/rdk-middleware-deployment/

# Copy device configuration (if available)
cp devices.json /mnt/usb/rdk-middleware-deployment/ 2>/dev/null || echo "# Create devices.json locally"
cp saved_sequences.json /mnt/usb/rdk-middleware-deployment/ 2>/dev/null || echo "# Create saved_sequences.json locally"
cp log_patterns.json /mnt/usb/rdk-middleware-deployment/ 2>/dev/null || true

# Copy documentation
cp DOCKER_RPI_*.md /mnt/usb/rdk-middleware-deployment/ 2>/dev/null || true

sync
```

### 2. Deploy on Target Raspberry Pi:

```bash
# Mount USB on target Pi
mkdir -p ~/rdk-deployment
mount /dev/sda1 ~/rdk-deployment  # Adjust device name

# Copy to home directory
cp -r ~/rdk-deployment/rdk-middleware-deployment ~/ 
cd ~/rdk-middleware-deployment

# Make deployment script executable
chmod +x docker-rpi-quickstart.sh

# Run deployment
sudo ./docker-rpi-quickstart.sh
```

### 3. Alternative: Direct Docker Deployment

```bash
cd ~/rdk-middleware-deployment

# Build Docker image
sudo docker build -f Dockerfile.rpi -t rdk-middleware:rpi .

# Run container
sudo docker-compose -f docker-compose.rpi.yml up -d

# Check status
sudo docker ps
```

---

## File Size Summary

| Component | Size | Notes |
|-----------|------|-------|
| controllers/ | 252K | ✅ Include |
| models/ | 172K | ✅ Include |
| services/ | 476K | ✅ Include |
| utils/ | ~200K | ✅ Include |
| templates/ | 1.2M | ✅ Include |
| static/ | 956K | ✅ Include |
| config_*.py | ~500K | ✅ Include |
| app.py | ~200K | ✅ Include |
| requirements.txt | ~20K | ✅ Include |
| Docker files | ~50K | ✅ Include |
| **TOTAL** | **~4.5MB** | USB ready |
| + Data files (optional) | ~50MB | devices.json, etc |
| venv/ | 556MB | DON'T include |
| screenshots/ | 703MB | DON'T include |

**USB Recommendation:** 16GB or larger (provides plenty of space for logs, screenshots during operation)

---

## Critical Configuration After Deployment

After copying files to target Raspberry Pi, configure:

1. **devices.json** - Update IP addresses for your target devices
2. **config_ssh_connection.py** - Configure SSH ports, timeouts
3. **config_email.py** - Configure email notifications  
4. **config_commands.py** - Customize device commands
5. **Environment Variables** - Set in docker-compose.rpi.yml:
   ```yaml
   environment:
     - FLASK_ENV=production
     - SMTP_HOST=smtp.gmail.com
     - SENDER_EMAIL=your-email@gmail.com
     - SECRET_KEY=your-secret-key
   ```

---

## Automatic USB Preparation Script

Save as `prepare-usb-deployment.sh`:

```bash
#!/bin/bash

USB_PATH="${1:-.}"
DEPLOY_DIR="$USB_PATH/rdk-middleware-deployment"

echo "📦 Preparing RDK Middleware for USB Deployment..."
echo "📁 Target: $DEPLOY_DIR"

# Create deployment directory
mkdir -p "$DEPLOY_DIR"

# Copy application files
echo "📋 Copying application files..."
cp -r controllers models services utils templates static "$DEPLOY_DIR/"
cp config_*.py app.py requirements.txt "$DEPLOY_DIR/"

# Copy deployment files
echo "🐳 Copying Docker configuration..."
cp Dockerfile.rpi docker-compose.rpi.yml .dockerignore "$DEPLOY_DIR/"
cp docker-rpi-quickstart.sh "$DEPLOY_DIR/"
chmod +x "$DEPLOY_DIR/docker-rpi-quickstart.sh"

# Copy configuration
echo "⚙️ Copying configuration files..."
cp devices.json saved_sequences.json log_patterns.json "$DEPLOY_DIR/" 2>/dev/null || true

# Copy documentation
echo "📖 Copying documentation..."
cp DOCKER_RPI_*.md "$DEPLOY_DIR/" 2>/dev/null || true

# Calculate size
SIZE=$(du -sh "$DEPLOY_DIR" | cut -f1)
echo ""
echo "✅ Deployment package ready!"
echo "📊 Total size: $SIZE"
echo "📁 Location: $DEPLOY_DIR"
echo ""
echo "Next steps on target Raspberry Pi:"
echo "  1. Mount USB: mkdir ~/rdk && mount /dev/sda1 ~/rdk"
echo "  2. Copy files: cp -r ~/rdk/rdk-middleware-deployment ~/"
echo "  3. Deploy: cd ~/rdk-middleware-deployment && chmod +x *.sh && ./docker-rpi-quickstart.sh"
```

Usage:
```bash
chmod +x prepare-usb-deployment.sh
sudo ./prepare-usb-deployment.sh /mnt/usb
```

---

## Verification Checklist Before USB Deployment

- [ ] All Python files copied (`*.py`)
- [ ] All directories present (controllers, models, services, templates, static, utils)
- [ ] requirements.txt present
- [ ] Docker files present (Dockerfile.rpi, docker-compose.rpi.yml)
- [ ] Deployment scripts executable (*.sh)
- [ ] Configuration files updated for target environment
- [ ] USB capacity sufficient (minimum 16GB recommended)
- [ ] Test USB on one Pi before mass deployment
