"""
Device Lock Management Utilities - Enhanced with Lock Refresh and Validation

This module provides improved device locking mechanisms to prevent:
- Lock expiration during long-running jobs
- Concurrent access to devices by multiple jobs
- Race conditions in device acquisition
"""

from datetime import datetime, timedelta, timezone
from models.device_lock import DeviceLock
import time

class DeviceLockManager:
    """Enhanced device lock management with refresh and validation"""
    
    @staticmethod
    def calculate_job_duration(execution_queue, iterations):
        """
        Calculate realistic lock duration based on job parameters.
        
        Args:
            execution_queue: List of methods to execute with parameters
            iterations: Number of iterations
        
        Returns:
            int: Estimated duration in seconds with 50% safety buffer
        """
        total_seconds = 0
        
        for queue_item in execution_queue:
            method = queue_item.get('method', '')
            
            if method == 'deepsleep':
                sleep_duration_minutes = queue_item.get('sleep_duration_minutes', 60)
                # deepsleep: 60s pre-check + (duration * 60) + 300s post-processing
                total_seconds += 60 + (sleep_duration_minutes * 60) + 300
            
            elif method == 'wait':
                wait_seconds = queue_item.get('wait_seconds', 0)
                total_seconds += wait_seconds + 10  # 10s overhead
            
            elif method == 'reboot' or 'reboot' in method:
                # Reboot methods typically take 3-5 minutes
                total_seconds += 300
            
            elif method == 'ir_test':
                # IR test: 1-2 minutes
                total_seconds += 120
            
            elif method == 'voice_command':
                # Voice command: 30-60 seconds
                total_seconds += 90
            
            elif method == 'screenshot' or 'screen' in method:
                # Screenshot operations: 20-30 seconds
                total_seconds += 60
            
            else:
                # Default: 60 seconds per method
                total_seconds += 60
        
        # Multiply by iterations and add 50% buffer for safety
        total_with_buffer = int((total_seconds * iterations) * 1.5)
        
        # Minimum duration: 5 minutes; Maximum: 24 hours
        min_duration = 300
        max_duration = 86400
        
        final_duration = max(min_duration, min(max_duration, total_with_buffer))
        
        return final_duration
    
    @staticmethod
    def acquire_lock_with_duration(device_ip, device_name, user_id, job_id, 
                                   execution_queue, iterations):
        """
        Acquire device lock with duration calculated from job parameters.
        
        Args:
            device_ip: Device IP address
            device_name: Device name
            user_id: User ID requesting the lock
            job_id: Job ID for tracking
            execution_queue: Job execution queue
            iterations: Number of iterations
        
        Returns:
            DeviceLock object or None if lock cannot be acquired
        """
        # Check if already locked
        if DeviceLock.is_device_locked(device_ip):
            existing_lock = DeviceLock.get_device_lock(device_ip)
            return None  # Device is locked
        
        # Calculate duration
        duration_seconds = DeviceLockManager.calculate_job_duration(
            execution_queue, 
            iterations
        )
        
        # Acquire lock
        lock = DeviceLock.lock_device(
            device_ip=device_ip,
            device_name=device_name,
            user_id=user_id,
            job_id=job_id,
            estimated_duration_seconds=duration_seconds
        )
        
        return lock
    
    @staticmethod
    def refresh_lock(device_ip, job_id, execution_queue, remaining_iterations):
        """
        Refresh device lock for remaining iterations.
        
        Call this at the START of each iteration to ensure lock doesn't expire.
        
        Args:
            device_ip: Device IP address
            job_id: Job ID (current owner)
            execution_queue: Job execution queue
            remaining_iterations: How many iterations are left to do
        
        Returns:
            bool: True if lock was refreshed, False if cannot refresh (lock lost)
        """
        # Check if device is still locked by THIS job
        current_lock = DeviceLock.get_device_lock(device_ip)
        
        if not current_lock:
            # Lock is lost!
            return False
        
        if current_lock.job_id != job_id:
            # Lock is owned by another job!
            return False
        
        # Unlock current lock
        DeviceLock.unlock_device(device_ip)
        
        # Calculate new duration
        new_duration = DeviceLockManager.calculate_job_duration(
            execution_queue,
            remaining_iterations
        )
        
        # Re-acquire lock with new duration
        lock = DeviceLock.lock_device(
            device_ip=current_lock.device_ip,
            device_name=current_lock.device_name,
            user_id=current_lock.user_id,
            job_id=job_id,
            estimated_duration_seconds=new_duration
        )
        
        return True
    
    @staticmethod
    def is_lock_valid_for_job(device_ip, job_id):
        """
        Check if device lock is valid for THIS specific job.
        
        Args:
            device_ip: Device IP address
            job_id: Job ID to verify
        
        Returns:
            bool: True if device is locked by this job, False otherwise
        """
        lock = DeviceLock.get_device_lock(device_ip)
        
        if not lock:
            return False  # Not locked
        
        if lock.job_id != job_id:
            return False  # Locked by another job
        
        return True
    
    @staticmethod
    def wait_with_lock_validation(duration_seconds, device_ip, job_id, log_callback=None):
        """
        Wait for specified duration while periodically validating lock.
        
        Use this instead of time.sleep() during long waits (deepsleep, etc.)
        to ensure lock is still valid.
        
        Args:
            duration_seconds: How long to wait
            device_ip: Device IP to validate
            job_id: Job ID that should own the lock
            log_callback: Optional logging function
        
        Returns:
            bool: True if wait completed successfully, False if lock was lost
        
        Raises:
            RuntimeError: If lock was lost during wait
        """
        CHECK_INTERVAL = 60  # Check every 60 seconds
        elapsed = 0
        
        def log(msg):
            if log_callback:
                log_callback(msg)
            else:
                print(msg)
        
        while elapsed < duration_seconds:
            # Calculate how long to sleep
            remaining_wait = duration_seconds - elapsed
            sleep_duration = min(CHECK_INTERVAL, remaining_wait)
            
            # Sleep in chunks
            time.sleep(sleep_duration)
            elapsed += sleep_duration
            
            # Validate lock
            if not DeviceLockManager.is_lock_valid_for_job(device_ip, job_id):
                msg = f"❌ CRITICAL: Device lock lost during wait! Device {device_ip} no longer reserved for job {job_id}"
                log(msg)
                raise RuntimeError(msg)
            
            # Log progress
            if elapsed < duration_seconds:
                remaining = duration_seconds - elapsed
                log(f"  ⏱ Elapsed: {elapsed}s / {duration_seconds}s | Remaining: {remaining}s (lock valid ✓)")
        
        return True
